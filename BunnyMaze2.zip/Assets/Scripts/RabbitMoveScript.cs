﻿using UnityEngine;
using System.Collections;

public class RabbitMoveScript : MonoBehaviour
{
	// Use this for initialization
	void Start ()
    {
	
	}
	
	// Update is called once per frame
	void Update ()
    {
        //gameObject.transform.Translate(new Vector3(-0.1f, 0f, 0f));
	}
}
