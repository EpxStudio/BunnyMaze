﻿using UnityEngine;
using System.Collections;

public class PlayerScript : MonoBehaviour
{
    public GameObject GateLeft;
    public GameObject GateRight;

    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    bool hasRemovedGates = false;
    void Update()
    {
        if (Global.Bunnies == 12 && !hasRemovedGates)
        {
            GameObject.Destroy(GateLeft);
            GameObject.Destroy(GateRight);
            hasRemovedGates = true;
        }
    }
}

public static class Global
{
    public static int CarrotCount = 0;

    public static bool canOpenGates = false;

    public static int Bunnies = 0;
}